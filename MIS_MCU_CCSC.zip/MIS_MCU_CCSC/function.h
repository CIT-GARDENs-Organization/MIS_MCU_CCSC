#ifndef _FUNCTION_H
#define _FUNCTION_H

//initialize
void setting(void);

// initialize to 0x00 rxBuffer and rxBufferCount 
void clearRxBuffer(void);

// calcrate CRC
unsigned int8 calcCRC(char *data, int8 Length);

//fundamental function
void makeRxFlame(unsigned int8 rxBuffer[], int8 rxBufferCount);

#endif
