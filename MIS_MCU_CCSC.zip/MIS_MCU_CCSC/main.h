#ifndef MAIN_H
#define MAIN_H

#include <18F67J94.h>
#include "config.h"
#include "valueDefine.h"
#include "function.c"
#include "Mission.c"
#include "DataCopy.c"

#endif
